from django.apps import AppConfig


class AuthFinancesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'auth_finances'
